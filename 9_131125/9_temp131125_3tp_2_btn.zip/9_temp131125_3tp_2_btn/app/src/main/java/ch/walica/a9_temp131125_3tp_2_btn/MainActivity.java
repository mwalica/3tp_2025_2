package ch.walica.a9_temp131125_3tp_2_btn;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView tvText1, tvText2;
    private Button btnRandom;
    private int randomNumber1;
    private int randomNumber2;
    private Random random= new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvText1 = findViewById(R.id.tvText1);
        tvText2 = findViewById(R.id.tvText2);
        btnRandom = findViewById(R.id.btnRandom);

       randomScreen();

        btnRandom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                randomScreen();
            }
        });
    }


    private void randomScreen() {
        randomNumber1 = random.nextInt(81) + 16;
        randomNumber2 = random.nextInt(81) + 16;

        tvText1.setText(String.valueOf(randomNumber1));
        tvText2.setText(randomNumber2 + "");

        tvText1.setTextSize(randomNumber1);
        tvText2.setTextSize(randomNumber2);

        tvText1.setBackgroundColor(Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
        tvText2.setBackgroundColor(Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
    }
}