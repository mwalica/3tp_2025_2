package ch.walica.a13_temp201125_3tp2_visibility;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button btnShowHide;
    private TextView tvMsg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnShowHide = findViewById(R.id.btnShowHide);
        tvMsg = findViewById(R.id.tvMsg);

        btnShowHide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tvMsg.getVisibility() == View.INVISIBLE) {
                    tvMsg.setVisibility(View.VISIBLE);
                    btnShowHide.setText("Ukryj");
                } else {
                    tvMsg.setVisibility(View.INVISIBLE);
                    btnShowHide.setText("Pokaż");
                }

            }
        });



    }
}