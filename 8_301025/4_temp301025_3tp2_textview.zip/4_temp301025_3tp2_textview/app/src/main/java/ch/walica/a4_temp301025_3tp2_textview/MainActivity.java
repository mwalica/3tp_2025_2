package ch.walica.a4_temp301025_3tp2_textview;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvText1, tvText2;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        tvText1 = findViewById(R.id.tvText1);
        tvText2 = findViewById(R.id.tvText2);

        tvText1.setText("Nowy tekst ustwiony w Javie");
        tvText2.setText(getResources().getString(R.string.text_1));
        tvText2.setBackgroundColor(Color.BLUE);
        tvText1.setBackgroundColor(Color.rgb(255, 12, 56));
        tvText1.setTextColor(Color.rgb(33, 45, 255));
        tvText2.setTextColor(getColor(R.color.color_3));

    }
}

