package ch.walica.a51_temp50326_3tp2_savainstantorientacja;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button btnAdd, btnSub;
    private TextView tvCounter;
    private int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAdd = findViewById(R.id.btnAdd);
        btnSub = findViewById(R.id.btnSub);
        tvCounter = findViewById(R.id.tvCounter);

        if(savedInstanceState != null) {
            counter = savedInstanceState.getInt("count_key");
        }

        tvCounter.setText(String.valueOf(counter));

        btnAdd.setOnClickListener(view -> {
            counter++;
            tvCounter.setText(String.valueOf(counter));
        });

        btnSub.setOnClickListener(view -> {
            counter--;
            tvCounter.setText(String.valueOf(counter));
        });

    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("count_key", counter);
    }
}