package ch.walica.a48_temp120226_3tp2_textwatcher_constrain;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etEnteredText;
    private TextView tvLiveResult;
    private Button btnShow;
    private String enteredText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etEnteredText = findViewById(R.id.etEnteredText);
        tvLiveResult = findViewById(R.id.tvLiveResult);
        btnShow = findViewById(R.id.btnShow);

        tvLiveResult.setText(enteredText);

        etEnteredText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                enteredText = charSequence.toString();
                btnShow.setEnabled(!enteredText.isEmpty());
                tvLiveResult.setText(enteredText);
            }
        });

        btnShow.setOnClickListener(view -> {
            Toast.makeText(this, enteredText, Toast.LENGTH_SHORT).show();
        });
    }
}