package ch.walica.temp80125_3tp2_1;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;
    private ImageView ivImage;
    private int count = 0;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvResult = findViewById(R.id.tvResult);
        ivImage = findViewById(R.id.ivImage);

        ivImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int randomNum = random.nextInt(6) + 1;
                switch(randomNum) {
                    case 1:
                        ivImage.setImageResource(R.drawable.one);
                        break;
                    case 2:
                        ivImage.setImageResource(R.drawable.two);
                        break;
                    case 3:
                        ivImage.setImageResource(R.drawable.three);
                        break;
                    case 4:
                        ivImage.setImageResource(R.drawable.four);
                        break;
                    case 5:
                        ivImage.setImageResource(R.drawable.five);
                        break;
                    case 6:
                        ivImage.setImageResource(R.drawable.six);
                        break;
                }
                count += randomNum;
                tvResult.setText(String.valueOf(count));
                if(count >= 100) {
                    Toast.makeText(MainActivity.this, "Uzyskałeś wynik 100 lub wiecej", Toast.LENGTH_SHORT).show();
                    count = 0;
                }
            }
        });
    }
}