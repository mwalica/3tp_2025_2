package ch.walica.a26_temp80126_3tp2_frame_layout;

import static android.view.View.INVISIBLE;
import static android.view.View.VISIBLE;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button btnNewYork, btnParis;
    private ImageView ivNewYork, ivParis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnParis = findViewById(R.id.btnParis);
        btnNewYork = findViewById(R.id.btnNewYork);
        ivParis = findViewById(R.id.ivParis);
        ivNewYork = findViewById(R.id.ivNewYork);

        btnParis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnParis.setVisibility(INVISIBLE);
                ivParis.setVisibility(VISIBLE);
            }
        });

        btnNewYork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnNewYork.setVisibility(INVISIBLE);
                ivNewYork.setVisibility(VISIBLE);
            }
        });

        ivParis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ivParis.setVisibility(INVISIBLE);
                btnParis.setVisibility(VISIBLE);
            }
        });

        ivNewYork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ivNewYork.setVisibility(INVISIBLE);
                btnNewYork.setVisibility(VISIBLE);
            }
        });
    }
}