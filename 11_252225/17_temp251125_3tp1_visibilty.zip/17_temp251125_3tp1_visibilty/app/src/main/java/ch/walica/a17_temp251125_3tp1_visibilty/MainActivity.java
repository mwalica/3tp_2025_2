package ch.walica.a17_temp251125_3tp1_visibilty;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button btnShowHide;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnShowHide = findViewById(R.id.btnShowHide);
        tvResult = findViewById(R.id.tvResult);

        btnShowHide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tvResult.getVisibility() == View.INVISIBLE) {
                    tvResult.setVisibility(View.VISIBLE);
                    btnShowHide.setText("Ukryj");
                } else {
                    tvResult.setVisibility(View.INVISIBLE);
                    btnShowHide.setText("Pokaż");
                }

            }
        });

    }
}